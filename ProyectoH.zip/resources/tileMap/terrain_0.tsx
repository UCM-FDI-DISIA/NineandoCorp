<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="terrain_0" tilewidth="64" tileheight="64" tilecount="160" columns="10">
 <image source="../images/Map/terrain_0.png" width="640" height="1024"/>
</tileset>
